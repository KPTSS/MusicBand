﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication18
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)//при нажатии на кнопку, откроет следующую форму проверяя radiobutton
        {

            {
                if (radioButton1.Checked == true)
                {
                    Form3 f = new Form3();
                    f.Show();
                }
                if (radioButton2.Checked == true)
                {
                    Form4 a = new Form4();
                    a.Show();
                }
                if (radioButton3.Checked == true)
                {
                    Form5 b = new Form5();
                    b.Show();
                }
                if (radioButton4.Checked == true)
                {
                    Form6 c = new Form6();
                    c.Show();
                }
            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
        }
   
