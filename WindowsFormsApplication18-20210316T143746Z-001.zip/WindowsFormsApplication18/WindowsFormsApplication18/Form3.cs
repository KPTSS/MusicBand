﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media; //использование Виндоус Медиа для того чтобы найти звук в этом ноуте

namespace WindowsFormsApplication18
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void button1_Click_1(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)//при каждом нажатием на фотку, он должен будет издавать звуки
        {
            SoundPlayer Simple = new SoundPlayer(@"C:\Users\040125550751\Desktop\Новая папка\316898__jaz-the-man-2__do.wav");//расположение звука
            Simple.Play();//что бы он играл
        }

        private void pictureBox2_Click_1(object sender, EventArgs e)
        {
            SoundPlayer Simple = new SoundPlayer(@"C:\Users\040125550751\Desktop\Новая папка\316908__jaz-the-man-2__re.wav");
            Simple.Play();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            SoundPlayer Simple = new SoundPlayer(@"C:\Users\040125550751\Desktop\Новая папка\316906__jaz-the-man-2__mi.wav");
            Simple.Play();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            SoundPlayer Simple = new SoundPlayer(@"C:\Users\040125550751\Desktop\Новая папка\316904__jaz-the-man-2__fa.wav");
            Simple.Play();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            SoundPlayer Simple = new SoundPlayer(@"C:\Users\040125550751\Desktop\Новая папка\316912__jaz-the-man-2__sol.wav");
            Simple.Play();
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            SoundPlayer Simple = new SoundPlayer(@"C:\Users\040125550751\Desktop\Новая папка\316902__jaz-the-man-2__la.wav");
            Simple.Play();
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            SoundPlayer Simple = new SoundPlayer(@"C:\Users\040125550751\Desktop\Новая папка\316901__jaz-the-man-2__do-octave.wav");
            Simple.Play();
        }

        private void button1_Click_2(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
